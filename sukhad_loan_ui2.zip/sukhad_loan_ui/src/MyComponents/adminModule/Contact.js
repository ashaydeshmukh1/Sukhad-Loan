import React from 'react'

function Contact() {
  return (
    <><h1>This is Contact component</h1></>
  )
}

export default Contact