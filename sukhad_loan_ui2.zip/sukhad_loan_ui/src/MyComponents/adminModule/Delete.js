import React from 'react'

function Delete() {

    return (
        <>  Delete confirm
            <input type="button" onClick={`/applications`} value="Back" />
        </>
    )
}

export default Delete