import React from 'react'

function Personal() {
  return (
    <>
        Personal Details
    </>
  )
}

export default Personal