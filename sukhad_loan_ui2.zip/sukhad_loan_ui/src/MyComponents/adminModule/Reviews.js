import React from 'react'

function Reviews() {
  return (
    <>
        <h1>Reviews</h1>
    </>
  )
}

export default Reviews