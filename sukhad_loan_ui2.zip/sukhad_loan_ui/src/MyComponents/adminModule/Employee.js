import React from 'react'

function Employee() {
  return (
    <>
        Employee details
    </>
  )
}

export default Employee