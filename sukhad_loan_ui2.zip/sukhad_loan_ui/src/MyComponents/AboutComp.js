import React from 'react'

export default function AboutComp() {
  return (
    <div>
        <h1>This is About Component</h1>
    </div>
  )
}
