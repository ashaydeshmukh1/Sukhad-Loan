import React from 'react'

export default function ContactComp() {
  return (
    <div>
        <h1>This is Contact Component</h1>
    </div>
  )
}
