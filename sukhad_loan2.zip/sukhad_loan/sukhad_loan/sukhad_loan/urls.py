"""sukhad_loan URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from rest_framework.routers import DefaultRouter
from application_generation.views import InquiryModelViewSet, UserModelViewSet, FamilyModelViewSet, BankModelViewSet, ApplicationModelViewSet, DocumentModelViewSet, LoanModelViewSet, GuarantorModelViewSet, VendorModelViewSet, ActiveUserModelViewSet
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView, TokenVerifyView, TokenBlacklistView

from document_verification.views import VerificationViewSet, DocVerificationViewSet, UserVerificationViewSet

from disbursement.views import DisbursementViewSet, DisbursementApplicationModelViewSet, DisbursementBankModelViewSet, DisbursementDefaulterViewSet, DisbursementInstallmentViewSet, DisbursementActiveUserModelViewSet, DisbursementLoanModelViewSet, DisbursementVendorModelViewSet

from customer.views import UserDetailsModelViewSet, CustomerActiveUserModelViewSet, CustomerApplicationModelViewSet

from loan_sanctioning.views import LoanSanctionModelViewSet, ApplicationUpdateModelViewSet

from admin_module.views import AdminActiveUserModelViewSet

#loan representative
application = DefaultRouter()
application.register("inquiry", InquiryModelViewSet, basename='inquiry')
application.register("user", UserModelViewSet, basename='user')
application.register("family", FamilyModelViewSet, basename='family')
application.register("bank", BankModelViewSet, basename='bank')
application.register("application", ApplicationModelViewSet, basename='application')
application.register("document", DocumentModelViewSet, basename='document')
application.register("loan", LoanModelViewSet, basename='loan')
application.register("guarantor", GuarantorModelViewSet, basename='guarantor')
application.register("vendor", VendorModelViewSet, basename='vendor')
application.register("activeuser", ActiveUserModelViewSet, basename='activeuser')

#operations head
verification = DefaultRouter()
verification.register("appverify", VerificationViewSet, basename="appverify")
verification.register("docverify", DocVerificationViewSet, basename="docverify" )
verification.register("userverify", UserVerificationViewSet, basename="userverify")

#account head
disbursement = DefaultRouter()
disbursement.register("vendor", DisbursementVendorModelViewSet, basename='vendor')
disbursement.register("application", DisbursementApplicationModelViewSet, basename='application')
disbursement.register("bank", DisbursementBankModelViewSet, basename='bank')
disbursement.register("loan", DisbursementLoanModelViewSet, basename='loan')
disbursement.register("disbursement",DisbursementViewSet, basename='disbursement')
disbursement.register("installment",DisbursementInstallmentViewSet, basename='installment')
disbursement.register("defaulter",DisbursementDefaulterViewSet, basename='defaulter')
disbursement.register("activeuser", DisbursementActiveUserModelViewSet, basename='activeuser')

#customer
customer = DefaultRouter()
customer.register("userdetails", UserDetailsModelViewSet, basename='userdetails')
customer.register("activeuser", CustomerActiveUserModelViewSet, basename='activeuser')

#loan_sanction
loan_sanction = DefaultRouter()
loan_sanction.register('loan_sanction', LoanSanctionModelViewSet, basename='loan_sanction')
loan_sanction.register('app_update', ApplicationUpdateModelViewSet, basename='app_update')

#Admin module
admin_module = DefaultRouter()
admin_module.register("user", UserModelViewSet, basename='user')
admin_module.register("application", CustomerApplicationModelViewSet, basename='application')
admin_module.register("activeuser", AdminActiveUserModelViewSet, basename='activeuser')
admin_module.register("userdetails", UserDetailsModelViewSet, basename='userdetails')

urlpatterns = [
    #loan representative
    path('admin/', admin.site.urls),
    path('application/', include(application.urls)),
    path('obtain_token/', TokenObtainPairView.as_view()),
    path('refresh_token/', TokenRefreshView.as_view()),
    path('verify_token/', TokenVerifyView.as_view()),
    path('blacklist_token/', TokenBlacklistView.as_view()),

    #operations head
    # path('application/', include(application.urls)),
    path('verification/', include(verification.urls)),

    #account head
    path('disbursement/', include(disbursement.urls)),

    #customer
    path('customer/', include(customer.urls)),

    #loan_sanction
    path('loan_sanction/', include(loan_sanction.urls)),

    #Admin module
    path('admin_module/', include(admin_module.urls)),

] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
