from rest_framework import serializers
import logging
from .models import Defaulter,Disbursement,Installment
from application_generation.models import Loan,Bank,Application,Vendor
from django.contrib.auth import get_user_model
from django.contrib.auth.hashers import make_password



logger=logging.getLogger('django')

User = get_user_model()
class UserSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = User
        fields = ('id', 'email', 'password', 'first_name', 'last_name', 'dob', 'gender', 'address', 'city', 'state', 'country', 'pin_code', 'mobile', 'photo', 'signature', 'role')
    def create(self, validated_data):
        return User.objects.create_user(**validated_data)

class DefaulterSerializer(serializers.ModelSerializer):
    class Meta:
        user=UserSerializer
        model=Defaulter
        fields='__all__'
        def create(self, validated_data):
            return Defaulter.objects.create(**validated_data)

class ApplicationSerializer(serializers.ModelSerializer):
    class Meta:
        model=Application
        fields='__all__'
        #read_only_fields=('user', 'aadhaar_no', 'pan_no', 'type_of_employment', 'business_title', 'business_type', 'business_address', 'gst_registration_no', 'business_license_no', 'expected_average_annual_turnover', 'years_in_current_business', 'collateral', 'status', 'application_timestamp', 'remark')

class LoanSerializer(serializers.ModelSerializer):
    class Meta:
        model = Loan
        fields = '__all__'
        #read_only_fields=('application','loan_principal_amount','loan_tenure','interest_rate','total_amount_and_processing_fees','installment','maturity_date','sanction_letter','status','response_timestamp','remark')

class VendorSerializer(serializers.ModelSerializer):
    class Meta:
        model = Vendor
        fields = '__all__'

class BankSerializer(serializers.ModelSerializer):
    class Meta:
        model=Bank
        fields='__all__'
        #read_only_fields=('user','bank_name','current_account_no','ifsc_code','passbook_copy ')

class DisbursementSerializer(serializers.ModelSerializer):

    #loan=LoanSerializer(many=True)
    class Meta:
        model=Disbursement
        fields='__all__'
        def create(self, validated_data):
            return Disbursement.objects.create(**validated_data)


class InstallmentSerializer(serializers.ModelSerializer):
    class Meta:
        user=UserSerializer
        loan=LoanSerializer(read_only=True)
        model=Installment
        fields='__all__'

        def create(self, validated_data):
            return Installment.objects.create(**validated_data)


User = get_user_model()
class ActiveUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ('id', 'email', 'password', 'first_name', 'last_name', 'dob', 'gender', 'address', 'city', 'state', 'country', 'pin_code', 'mobile', 'photo', 'signature', 'role')
        lookup_field = 'email'

    def create(self, validated_data):
        return User.objects.create_user(**validated_data)




