from rest_framework import viewsets
from .serializers import DefaulterSerializer,InstallmentSerializer,DisbursementSerializer,LoanSerializer,BankSerializer,ApplicationSerializer,VendorSerializer,ActiveUserSerializer
from .models import Defaulter,Installment,Disbursement
from rest_framework.permissions import BasePermission
from application_generation.models import Loan,Bank,Application,Vendor
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework.permissions import IsAuthenticated,AllowAny
from django.contrib.auth import get_user_model


class PostOnly(BasePermission):
    def has_permission(self, request, view):
        return bool(
            request.method == 'POST' or

            request.user and
            request.user.is_authenticated
        )




# Create your views here.
class DisbursementViewSet(viewsets.ModelViewSet):
    authentication_classes = [JWTAuthentication]
    permission_classes = [PostOnly]
    queryset=Disbursement.objects.all()
    serializer_class = DisbursementSerializer
    lookup_field = 'disbursement'


class DisbursementInstallmentViewSet(viewsets.ModelViewSet):
    authentication_classes = [JWTAuthentication]
    permission_classes = [PostOnly]
    queryset = Installment.objects.all()
    serializer_class = InstallmentSerializer
    lookup_field = 'disbursement'

class DisbursementDefaulterViewSet(viewsets.ModelViewSet):
    queryset=Defaulter.objects.all()
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]
    serializer_class = DefaulterSerializer
    lookup_field = 'disbursement'

class DisbursementLoanModelViewSet(viewsets.ModelViewSet):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]
    #permission_classes = [PostOnly]
    queryset = Loan.objects.all()
    serializer_class = LoanSerializer
    http_method_names = ['get']
    lookup_field = 'disbursement'

class DisbursementApplicationModelViewSet(viewsets.ModelViewSet):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]
    queryset = Application.objects.all()
    serializer_class = ApplicationSerializer
    http_method_names = ['get']
    lookup_field = 'disbursement'

class DisbursementBankModelViewSet(viewsets.ModelViewSet):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]
    #permission_classes = [GetOnly]
    queryset = Bank.objects.all()
    serializer_class = BankSerializer
    http_method_names = ['get']
    lookup_field = 'disbursement'

class DisbursementVendorModelViewSet(viewsets.ModelViewSet):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]
    queryset = Vendor.objects.all()
    serializer_class = VendorSerializer
    http_method_names = ['get']
    lookup_field = 'disbursement'

User = get_user_model()
class DisbursementActiveUserModelViewSet(viewsets.ModelViewSet):
    authentication_classes = [JWTAuthentication]
    permission_classes = [PostOnly]
    queryset = User.objects.all()
    serializer_class = ActiveUserSerializer
    lookup_field = 'email'
    lookup_value_regex = "[^/]+"




