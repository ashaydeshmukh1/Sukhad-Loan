# from django.contrib import admin
# from .models import Disbursement,Installment,Defaulter
# from application_generation.models import Loan,Bank,Application,Vendor
# from django.contrib.auth import get_user_model
# User=get_user_model()
# # Register your models here.
# @admin.register(Disbursement)
# class DisbursementAdmin(admin.ModelAdmin):
#     list_display = ['loan','insurance_doc','payment_mode','net_disbursed_amount','disbursed_to_account_no','receipt_doc','status','response_timestamp']
#
# @admin.register(Installment)
# class InstallmentAdmin(admin.ModelAdmin):
#     list_display = ['loan','remaining_amount','installment_no','monthly_installment_amount','installment_expected_date','installment_paid_date','penalty_amount','status']
#
# @admin.register(Defaulter)
# class DefaulterAdmin(admin.ModelAdmin):
#     list_display = ['user','default_amount','pending_since_date']
#
# @admin.register(Loan)
# class LoanAdmin(admin.ModelAdmin):
#     list_display = ['application','loan_principal_amount','loan_tenure','interest_rate','total_amount_and_processing_fees']
# @admin.register(Application)
# class ApplicationAdmin(admin.ModelAdmin):
#     list_display = ['user','aadhaar_no','type_of_employment']
#
# @admin.register(User)
# class UserAdmin(admin.ModelAdmin):
#     list_display = ['first_name', 'last_name', 'mobile']
#
# @admin.register(Bank)
# class BankAdmin(admin.ModelAdmin):
#     list_display = ['user','bank_name','current_account_no','ifsc_code','passbook_copy']
#
# @admin.register(Vendor)
# class VendorAdmin(admin.ModelAdmin):
#     list_display = ['application','name']
#
