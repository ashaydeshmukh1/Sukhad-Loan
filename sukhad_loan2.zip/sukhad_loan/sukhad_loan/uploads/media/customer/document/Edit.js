import React, { useEffect, useState } from 'react'
import {useParams, useNavigate} from 'react-router-dom';
import { getUserByIdAPI, updateUserAPI } from '../apicalls/MyAPIServices';
import { useForm } from 'react-hook-form';

function Edit() {
  const {id} = useParams('id');
  const [user, setUser] = useState({});
  const nav = useNavigate();
  const {register,handleSubmit,setValue}= useForm();
  useEffect(() =>{
    getUserById();
  },[])

  const getUserById =async () =>{
    const data = await getUserByIdAPI(id);
    setUser(data.data);
    
  }
  const updateUser = async (userData) => {
    console.log(userData)
    await updateUserAPI(userData);
    nav('/display');
  }
  return (
    <>
      <div className='container'>
      <h3 className='text-info'>User Updation</h3>
        <form onSubmit={handleSubmit(updateUser)}>
          <input type="hidden" {...register('id')} {...setValue("id",user.id)} />
          <div className="form-group">
            <label for="exampleUsername">Username</label>
            <input type="text" className="form-control" id="exampleUsername" {...register('username')} {...setValue('username',user.username)} aria-describedby="usernameHelp" placeholder="Enter Username"/>
          </div>
          <div className="form-group">
            <label for="exampleInputFirstName">FirstName</label>
            <input type="text" className="form-control" id="exampleInputFirstName" {...register('first_name')} {...setValue('first_name',user.first_name)} aria-describedby="FirstNameHelp" placeholder="Enter FirstName"/>
          </div>
          <div className="form-group">
            <label for="exampleInputLastName">LastName</label>
            <input type="text" className="form-control" id="exampleInputLastName" {...register('last_name')} {...setValue('last_name',user.last_name)} aria-describedby="LastNameHelp" placeholder="Enter LastName"/>
          </div>
          <div className="form-group">
            <label for="exampleInputEmail1">Email address</label>
            <input type="email" className="form-control" id="exampleInputEmail1" {...register('email')} {...setValue('email',user.email)} aria-describedby="emailHelp" placeholder="Enter email"/>
            <small id="emailHelp" className="form-text text-muted">We'll never share your email with anyone else.</small>
          </div>
          {/* <div className="form-group">
            <input type="hidden" className="form-control" id="exampleInputPassword1" {...register('password')} {...setValue('password',user.password)} placeholder="Password"/>
          </div> */}
          <button type="submit" className="btn btn-primary">Submit</button>
        </form>
      </div>
    </>
  )
}

export default Edit;