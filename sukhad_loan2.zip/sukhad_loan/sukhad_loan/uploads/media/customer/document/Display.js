import React, { useEffect, useState } from 'react'
import { NavLink } from 'react-router-dom';
import { allUserAPI, deleteUserAPI } from '../apicalls/MyAPIServices';
function Display() {
  const [flag, setFlag] = useState(true);
  const [users,setUsers] = useState([]);
  useEffect(() => {
    getAllUserData();
  },[flag])
  const getAllUserData =async () => {
    const data = await allUserAPI();
    //setFlag(false);
    setUsers(data.data);
  }
  const deleteUser =async id =>{
    await deleteUserAPI(id);
    setFlag(!flag)
  }
  return (
    <>
      <div className='container'>
        <table className="table table-dark">
          <thead>
            <tr>
              <th scope="col">#</th>
              {/* <th scope="col">FirstName</th>
              <th scope="col">LastName</th> */}
              <th scope="col">Username</th>
              <th scope="col">Email</th>
              <th scope="col">UPDATE</th>
              <th scope="col">DELETE</th>
              
              
            </tr>
          </thead>
          <tbody className='table-info'>
            { users.map(user=>{
              return(
            <tr>
              <th scope="row">{user.id}</th>
                {/* <td>{user.first_name}</td>
                <td>{user.last_name}</td> */}
                <td>{user.username}</td>
                <td>{user.email}</td>
                <td><NavLink to={`/edit/${user.id}`}><i className='bi bi-pencil-square text-primary'></i></NavLink></td>
                <td><i className='bi bi-trash text-danger' onClick={() => deleteUser(user.id)}></i></td>
              </tr>)
              })
             } 
          </tbody>
        </table>
      </div>
    </>
  )
}

export default Display;