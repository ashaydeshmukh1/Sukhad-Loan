import axios from "axios";

const url = "http://127.0.0.1:8000/api/user/"
const users_url = "http://127.0.0.1:8000/app/users/"
export const addUserAPI = (userData) => {
    return axios.post(url,userData);
}

export const allUserAPI = () =>{
    return axios.get(users_url);
}

export const deleteUserAPI = (id) => {
    return axios.delete(url+id);
}

export const getUserByIdAPI = (id) => {
    return axios.get(url+id+"/");
}

export const updateUserAPI = (userData) => {
    return axios.patch(url+userData.id+"/",userData);
}