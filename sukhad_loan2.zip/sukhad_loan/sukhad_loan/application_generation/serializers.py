from rest_framework import serializers, fields
from .models import Inquiry, Family, Bank, Application, Document, Loan, Guarantor,Vendor
from django.contrib.auth import get_user_model


class InquirySerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Inquiry
        fields = ('id', 'first_name', 'last_name', 'email', 'mobile', 'message', 'inquiry_date', 'status', 'response_timestamp')
    def create(self, validated_data):
        return Inquiry.objects.create(**validated_data)


User = get_user_model()
class UserSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = User
        fields = ('id', 'email', 'password', 'first_name', 'last_name', 'dob', 'gender', 'address', 'city', 'state', 'country', 'pin_code', 'mobile', 'photo', 'signature', 'role')
    def create(self, validated_data):
        return User.objects.create_user(**validated_data)


class ActiveUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ('id', 'email', 'password', 'first_name', 'last_name', 'dob', 'gender', 'address', 'city', 'state', 'country', 'pin_code', 'mobile', 'photo', 'signature', 'role')
        lookup_field = 'email'


class FamilySerializer(serializers.ModelSerializer):
    class Meta:
        model = Family
        fields = ('id', 'user', 'father_name', 'father_profession', 'mother_name', 'mother_profession', 'marital_status', 'spouse_name', 'spouse_profession', 'mobile', 'address')
    def create(self, validated_data):
        return Family.objects.create(**validated_data)


class BankSerializer(serializers.ModelSerializer):
    class Meta:
        model = Bank
        fields = ('id', 'user', 'bank_name', 'current_account_no', 'ifsc_code', 'passbook_copy')
    def create(self, validated_data):
        return Bank.objects.create(**validated_data)

class ApplicationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Application
        fields = ('id', 'user', 'aadhaar_no', 'pan_no', 'type_of_employment', 'business_title', 'business_type', 'business_address', 'gst_registration_no', 'business_license_no', 'expected_average_annual_turnover', 'years_in_current_business', 'collateral', 'status', 'application_timestamp', 'remark')
    def create(self, validated_data):
        return Application.objects.create(**validated_data)

class DocumentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Document
        fields = ('id', 'application', 'aadhaar_card', 'pan_card', 'business_address_proof_or_copy_of_rent_agreement', 'electric_bill', 'msme_certificate', 'gst_certificate', 'udyog_aadhaar_registration', 'business_license', 'business_plan_or_proposal', 'three_year_itr_with_balance_sheet', 'collateral_document', 'stamp_duty', 'status', 'response_timestamp', 'remark')
    def create(self, validated_data):
        return Document.objects.create(**validated_data)

class LoanSerializer(serializers.ModelSerializer):
    class Meta:
        model = Loan
        fields = ('id', 'application', 'loan_principal_amount', 'loan_tenure', 'interest_rate', 'total_amount_and_processing_fees', 'installment', 'maturity_date', 'sanction_letter', 'status', 'response_timestamp', 'remark')
    def create(self, validated_data):
        return Loan.objects.create(**validated_data)

class GuarantorSerializer(serializers.ModelSerializer):
    class Meta:
        model = Guarantor
        fields = ('id', 'application', 'relation_with_customer', 'name', 'dob', 'gender', 'email', 'address', 'city', 'state', 'country', 'pin_code', 'mobile', 'photo', 'profession', 'income_certificate', 'bank_name', 'current_account_no', 'passbook_copy', 'ifsc_code')
    def create(self, validated_data):
        return Guarantor.objects.create(**validated_data)

class VendorSerializer(serializers.ModelSerializer):
    class Meta:
        model = Vendor
        fields = ('id', 'application', 'name', 'vendor_type', 'email', 'address', 'city', 'state', 'country', 'pin_code', 'mobile', 'bank_name', 'passbook_copy', 'current_account_no', 'ifsc_code')
    def create(self, validated_data):
        return Vendor.objects.create(**validated_data)
