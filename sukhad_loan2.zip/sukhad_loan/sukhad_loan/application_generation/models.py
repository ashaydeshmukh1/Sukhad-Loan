from django.db import models
from .utility import *
from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin, BaseUserManager


#######################################################################################################################


class CustomUserManager(BaseUserManager):
    def _create_user(self, email, password, first_name, last_name, mobile, **extra_fields):
        if not email:
            raise ValueError("Email must be provided")
        if not password:
            raise ValueError("password must be provided")

        user = self.model(
            email=self.normalize_email(email),
            first_name=first_name,
            last_name=last_name,
            mobile=mobile,
            **extra_fields
        )

        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_user(self, email, password, first_name, last_name, mobile, **extra_fields):
        extra_fields.setdefault("is_staff", True)
        extra_fields.setdefault("is_active", True)
        extra_fields.setdefault("is_superuser", False)
        extra_fields.setdefault("role", "customer")
        return self._create_user(email, password, first_name, last_name, mobile, **extra_fields)

    def create_superuser(self, email, password, first_name, last_name, mobile, **extra_fields):
        extra_fields.setdefault("is_staff", True)
        extra_fields.setdefault("is_active", True)
        extra_fields.setdefault("is_superuser", True)
        extra_fields.setdefault("role", "admin")
        return self._create_user(email, password, first_name, last_name, mobile, **extra_fields)


class Inquiry(models.Model):
    first_name = models.CharField(max_length=250)
    last_name = models.CharField(max_length=250)
    email = models.EmailField(unique=True)
    mobile = models.CharField(max_length=10)
    message = models.TextField()
    inquiry_date = models.DateTimeField(auto_now_add=True, blank=True)
    status = models.CharField(max_length=50, default='', choices=INQUIRY_STATUS)
    response_timestamp = models.DateTimeField(auto_now=True, blank=True)

    def __str__(self):
        return f"{self.id}"


class User(AbstractBaseUser, PermissionsMixin):
    first_name = models.CharField(max_length=250)
    last_name = models.CharField(max_length=250)
    dob = models.DateField(default="2000-12-12", blank=True)
    gender = models.CharField(max_length=50, choices=GENDER_CHOICES)
    email = models.EmailField(db_index=True, max_length=50, unique=True)
    address = models.TextField()
    city = models.CharField(max_length=250)
    state = models.CharField(max_length=250)
    country = models.CharField(max_length=250)
    pin_code = models.IntegerField(default=0, blank=True)
    mobile = models.CharField(max_length=10)
    photo = models.ImageField(upload_to="media/customer/user/", default=0, blank=True)
    signature = models.ImageField(upload_to="media/customer/user/", default=0, blank=True)
    role = models.CharField(max_length=50, default='customer', choices=ROLE_CHOICES)
    is_staff = models.BooleanField(default=True)  # must for admin interface
    is_active = models.BooleanField(default=True)  # must
    is_superuser = models.BooleanField(default=False)

    objects = CustomUserManager()

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['first_name', 'last_name', 'mobile']

    class Meta:
        verbose_name = 'User'
        verbose_name_plural = 'Users'


class Family(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='Familys')
    father_name = models.CharField(max_length=250, default=0, blank=True)
    father_profession = models.CharField(max_length=250, default=0, blank=True)
    mother_name = models.CharField(max_length=250, default=0, blank=True)
    mother_profession = models.CharField(max_length=250, default=0, blank=True)
    marital_status = models.CharField(max_length=250, choices=MARITAL_STATUS, default=0, blank=True)
    spouse_name = models.CharField(max_length=250, default=0, blank=True)
    spouse_profession = models.CharField(max_length=250, default=0, blank=True)
    mobile = models.CharField(max_length=10, default=0, blank=True)
    address = models.TextField(default=0, blank=True)

    def __str__(self):
        return f"{self.id}"


class Bank(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='Banks')
    bank_name = models.CharField(max_length=250, default=0, blank=True)
    current_account_no = models.CharField(max_length=20, default=0, blank=True)
    ifsc_code = models.CharField(max_length=20, default=0, blank=True)
    passbook_copy = models.ImageField(upload_to='media/customer/bank/', default=0, blank=True)

    def __str__(self):
        return f"{self.id}"


class Application(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='Applications')
    aadhaar_no = models.CharField(max_length=12, default=0, blank=True)
    pan_no = models.CharField(max_length=10, default=0, blank=True)
    type_of_employment = models.CharField(max_length=250, choices=EMPLOYMENT_CHOICE, default=0, blank=True)
    business_title = models.CharField(max_length=250, default=0, blank=True)
    business_type = models.CharField(max_length=250, choices=BUSINESS_TYPE, default=0, blank=True)
    business_address = models.TextField(default=0, blank=True)
    gst_registration_no = models.CharField(max_length=50, default=0, blank=True)
    business_license_no = models.CharField(max_length=50, default=0, blank=True)
    expected_average_annual_turnover = models.CharField(max_length=250, default=0, blank=True)
    years_in_current_business = models.IntegerField(default=0, blank=True)
    collateral = models.CharField(max_length=250, default=0, blank=True)
    status = models.CharField(max_length=250, default='', choices=APPLICATION_STATUS)
    application_timestamp = models.DateTimeField(auto_now_add=True, blank=True)
    remark = models.CharField(max_length=250, default=0, blank=True)

    def __str__(self):
        return f"{self.id}"


class Guarantor(models.Model):
    application = models.OneToOneField(Application, on_delete=models.CASCADE, related_name='Guarantors')
    relation_with_customer = models.CharField(max_length=250, default=0, blank=True)
    name = models.CharField(max_length=150, default=0, blank=True)
    dob = models.DateField(default="2000-12-12", blank=True)
    gender = models.CharField(max_length=50,  default=0, blank=True, choices=GENDER_CHOICES)
    email = models.EmailField(default=0, blank=True)
    address = models.TextField(max_length=250, default=0, blank=True)
    city = models.CharField(max_length=50, default=0,blank=True)
    state = models.CharField(max_length=50, default=0,blank=True)
    country = models.CharField(max_length=250, default=0, blank=True)
    pin_code = models.IntegerField(default=0, blank=True)
    mobile = models.CharField(max_length=10,default=0, blank=True)
    photo = models.ImageField(upload_to='media/customer/guarantor/', default=0, blank=True)
    profession = models.CharField(max_length=250, default=0, blank=True)
    income_certificate = models.FileField(upload_to='media/customer/guarantor/', default=0, blank=True)
    bank_name = models.CharField(max_length=250, default=0, blank=True)
    current_account_no = models.CharField(max_length=20, default=0, blank=True)
    passbook_copy = models.FileField(upload_to='media/customer/guarantor/', default=0, blank=True)
    ifsc_code = models.CharField(max_length=20, default=0, blank=True)

    def __str__(self):
        return f'{self.id}'


class Document(models.Model):
    application = models.OneToOneField(Application, on_delete=models.CASCADE, related_name='Documents')
    aadhaar_card = models.FileField(upload_to='media/customer/document/', default=0, blank=True)
    pan_card = models.FileField(upload_to='media/customer/document/', default=0, blank=True)
    business_address_proof_or_copy_of_rent_agreement = models.FileField(upload_to='media/customer/document/', default=0, blank=True)
    electric_bill = models.FileField(upload_to='media/customer/document/', default=0, blank=True)
    msme_certificate = models.FileField(upload_to='media/customer/document/', default=0, blank=True)
    gst_certificate = models.FileField(upload_to='media/customer/document/', default=0, blank=True)
    udyog_aadhaar_registration = models.FileField(upload_to='media/customer/document/', default=0, blank=True)
    business_license = models.FileField(upload_to='media/customer/document/', default=0, blank=True)
    business_plan_or_proposal = models.FileField(upload_to='media/customer/document/', default=0, blank=True)
    three_year_itr_with_balance_sheet = models.FileField(upload_to='media/customer/document/', default=0, blank=True)
    collateral_document = models.FileField(upload_to='media/customer/document/', default=0, blank=True)
    stamp_duty = models.FileField(upload_to='media/customer/document/', default=0, blank=True)
    status = models.CharField(max_length=250, choices=DOCUMENT_STATUS_CHOICE, default=0, blank=True)
    response_timestamp = models.DateTimeField(auto_now=True, blank=True)
    remark = models.CharField(max_length=250, default=0, blank=True)

    def __str__(self):
        return f'{self.id}'


class Loan(models.Model):
    application = models.OneToOneField(Application, on_delete=models.CASCADE, related_name='Loans')
    loan_principal_amount = models.FloatField(default=0, blank=True)
    loan_tenure = models.FloatField(default=0, blank=True)
    interest_rate = models.FloatField(default=0, blank=True)
    total_amount_and_processing_fees = models.FloatField(default=0, blank=True)
    installment = models.IntegerField(default=0, blank=True)
    maturity_date = models.DateField(default="2000-12-12", blank=True)
    sanction_letter = models.FileField(upload_to='media/customer/loan/', default=0, blank=True)
    status = models.CharField(max_length=250, choices=LOAN_STATUS_CHOICE, default=0, blank=True)
    response_timestamp = models.DateTimeField(auto_now=True, blank=True)
    remark = models.CharField(max_length=250, default=0, blank=True)

    def __str__(self):
        return f'{self.id}'


class Vendor(models.Model):
    application = models.ForeignKey(Application, on_delete=models.CASCADE, related_name='Vendors')
    name = models.CharField(max_length=250, default=0, blank=True)
    vendor_type = models.CharField(max_length=250, default=0, blank=True)
    email = models.EmailField(default=0, blank=True)
    address = models.TextField(max_length=250, default=0, blank=True)
    city = models.CharField(max_length=250, default=0,blank=True)
    state = models.CharField(max_length=250, default=0, blank=True)
    country = models.CharField(max_length=250, default=0, blank=True)
    pin_code = models.IntegerField(default=0, blank=True)
    mobile = models.CharField(max_length=10,default=0, blank=True)
    bank_name = models.CharField(max_length=250, default=0, blank=True)
    passbook_copy = models.FileField(upload_to='media/customer/vendor/', default=0, blank=True)
    current_account_no = models.CharField(max_length=25, default=0, blank=True)
    ifsc_code = models.CharField(max_length=20, default=0, blank=True)

    def __str__(self):
        return f"{self.id}"
