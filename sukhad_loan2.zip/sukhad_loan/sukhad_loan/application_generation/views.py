from django.shortcuts import render
from rest_framework import viewsets
from .serializers import InquirySerializer, UserSerializer, FamilySerializer, BankSerializer, ApplicationSerializer, DocumentSerializer, LoanSerializer, GuarantorSerializer, VendorSerializer, ActiveUserSerializer
from .models import Inquiry, Family, Bank, Application, Document, Loan, Guarantor, Vendor
from django.contrib.auth import get_user_model
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework.permissions import BasePermission, IsAuthenticated
from django.core.mail import send_mail
from django.conf import settings
import logging
# Create your views here.



class PostOnly(BasePermission):
    def has_permission(self, request, view):
        return bool(
            request.method == 'POST' or
            request.user and
            request.user.is_authenticated
        )


class InquiryModelViewSet(viewsets.ModelViewSet):
    authentication_classes = [JWTAuthentication]
    permission_classes = [PostOnly]
    queryset = Inquiry.objects.all()
    serializer_class = InquirySerializer

    def partial_update(self, request, *args, **kwargs):
        print(request.data)
        print(request.data.get('first_name'))
        email_from = settings.EMAIL_HOST_USER
        subject = f'Sukhad Loan Inquiry Status'
        if request.data.get('status') == 'done':
            message = f'Dear {request.data.get("first_name")},\n'\
                      f'\tYour inquiry for loan is ACCEPTED. Please click following link to generate an application for loan.\n '\
                      f'\t http://localhost:3000/custuser \n\n'\
                      f'Sincerely,\n'\
                      f'Sukhad Loan'
            send_mail(subject, message, email_from, [request.data.get('email')])
        elif request.data.get('status') == 'rejected':
            message = f'Dear {request.data.get("first_name")},\n'\
                      f'\tYour inquiry for loan is REJECTED. Please try again proper information.\n\n '\
                      f'Sincerely,\n'\
                      f'Sukhad Loan'
            send_mail(subject, message, email_from, [request.data.get('email')])
        else:
            message = f'Dear {request.data.get("first_name")},\n'\
                      f'\tYour inquiry for loan is on hold. Please wait until we revert back.\n\n '\
                      f'Sincerely,\n'\
                      f'Sukhad Loan'
            send_mail(subject, message, email_from, [request.data.get('email')])
        kwargs['partial'] = True
        return self.update(request, *args, **kwargs)



User = get_user_model()
class UserModelViewSet(viewsets.ModelViewSet):
    authentication_classes = [JWTAuthentication]
    permission_classes = [PostOnly]
    queryset = User.objects.all()
    serializer_class = UserSerializer


class FamilyModelViewSet(viewsets.ModelViewSet):
    authentication_classes = [JWTAuthentication]
    permission_classes = [PostOnly]
    queryset = Family.objects.all()
    serializer_class = FamilySerializer
    lookup_field = 'user'


class BankModelViewSet(viewsets.ModelViewSet):
    authentication_classes = [JWTAuthentication]
    permission_classes = [PostOnly]
    queryset = Bank.objects.all()
    serializer_class = BankSerializer
    lookup_field = 'user'


class ApplicationModelViewSet(viewsets.ModelViewSet):
    authentication_classes = [JWTAuthentication]
    permission_classes = [PostOnly]
    queryset = Application.objects.all()
    serializer_class = ApplicationSerializer

    def partial_update(self, request, *args, **kwargs):
        print(request.data)
        application_id = kwargs.get('pk')
        application_user = Application.objects.filter(id=application_id).values('user')
        user_id = application_user[0].get('user')
        user_rec = User.objects.filter(id=user_id).values('email', 'first_name')
        user_email = user_rec[0].get('email')
        first_name = user_rec[0].get('first_name')
        print(user_rec)
        # print(request.data.get('first_name'))
        email_from = settings.EMAIL_HOST_USER
        subject = f'Sukhad Loan Application Status'
        if request.data.get('status') == 'generated':
            message = f'Dear {first_name},\n'\
                      f'\tYour loan application is GENERATED. Now you can login from our Sukhad Loan portal.\n '\
                      f'\t http://localhost:3000/login \n'\
                      f'\t Remark: {request.data.get("remark")}\n\n'\
                      f'Sincerely,\n'\
                      f'Sukhad Loan'
            send_mail(subject, message, email_from, [user_email])
        elif request.data.get('status') == 'rejected':
            message = f'Dear {first_name},\n' \
                      f'\tYour loan application is REJECTED. Please send your inquiry.\n ' \
                      f'\t http://localhost:3000/inquiry \n' \
                      f'\t Remark: {request.data.get("remark")}\n\n' \
                      f'Sincerely,\n' \
                      f'Sukhad Loan'
            send_mail(subject, message, email_from, [user_email])
        else:
            pass
        kwargs['partial'] = True
        return self.update(request, *args, **kwargs)


class DocumentModelViewSet(viewsets.ModelViewSet):
    authentication_classes = [JWTAuthentication]
    permission_classes = [PostOnly]
    queryset = Document.objects.all()
    serializer_class = DocumentSerializer
    lookup_field = 'application'


class LoanModelViewSet(viewsets.ModelViewSet):
    authentication_classes = [JWTAuthentication]
    permission_classes = [PostOnly]
    queryset = Loan.objects.all()
    serializer_class = LoanSerializer
    lookup_field = 'application'


class GuarantorModelViewSet(viewsets.ModelViewSet):
    authentication_classes = [JWTAuthentication]
    permission_classes = [PostOnly]
    queryset = Guarantor.objects.all()
    serializer_class = GuarantorSerializer
    lookup_field = 'application'


class VendorModelViewSet(viewsets.ModelViewSet):
    authentication_classes = [JWTAuthentication]
    permission_classes = [PostOnly]
    queryset = Vendor.objects.all()
    serializer_class = VendorSerializer
    lookup_field = 'application'


class ActiveUserModelViewSet(viewsets.ModelViewSet):
    authentication_classes = [JWTAuthentication]
    permission_classes = [PostOnly]
    queryset = User.objects.all()
    serializer_class = ActiveUserSerializer
    lookup_field = 'email'
    lookup_value_regex = "[^/]+"