from rest_framework import viewsets
from django.core.mail import send_mail
from sukhad_loan import settings
from .serializers import LoanSanctionModelSerializer, ApplicationModelSerializer
from application_generation.models import Loan, Application, User
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework.permissions import IsAuthenticated


class LoanSanctionModelViewSet(viewsets.ModelViewSet):
    authentication_classes =[JWTAuthentication]
    permission_classes = [IsAuthenticated]
    queryset = Loan.objects.all()
    serializer_class = LoanSanctionModelSerializer
    lookup_field = "application"   


class ApplicationUpdateModelViewSet(viewsets.ModelViewSet):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]
    queryset = Application.objects.all()
    serializer_class = ApplicationModelSerializer
    


    def partial_update(self, request, *args, **kwargs):
        print(request.data)
        application_id = kwargs.get('pk')
        application_user = Application.objects.filter(id=application_id).values('user')
        user_id = application_user[0].get('user')
        user_rec = User.objects.filter(id=user_id).values('email', 'first_name')
        user_email = user_rec[0].get('email')
        first_name = user_rec[0].get('first_name')
        print(user_email, first_name)

        print(user_rec)
        application_loan = Loan.objects.filter(application=application_id).values('status','remark','sanction_letter')
        loan_status = print(application_loan[0].get('status'))
        loan_remark = print(application_loan[0].get('remark'))
        loan_sanction_letter = application_loan[0].get('sanction_letter')
        print(application_loan)
        
        
        email_from = settings.EMAIL_HOST_USER
        subject = F'Sukhad Loan Application Status'
        if request.data.get('status') == 'sanctioned':
            message = F'Dear {first_name},\n'\
                    F'\t Your loan application is successfully SANCTIONED. Your Sanctioned Letter is attched to this mail.\n'\
                    f'\t Your amount will be disbursed soon.\n'\
                    F'\t Your Application Remark: {request.data.get("remark")} \n'\
                    F'\t Your Loan Status: {request.data.get("loanstatus")} \n'\
                    F'\t Your Loan Remark: {request.data.get("loanremark")} \n'\
                    F'\t Your Saction Letter: http://127.0.0.1:8000/media/{loan_sanction_letter} \n'\
                    F'\t To know more details, please visit http://localhost:3000/login \n\n'\
                    F'Regards, \n'\
                    F'Sukhad Loan'
            send_mail(subject, message, email_from, [user_email])
        elif request.data.get('status') == 'rejected':
            message = f'Dear {first_name},\n' \
                      f'\tYour loan application is REJECTED. Please send your inquiry.\n ' \
                      f'\t http://localhost:3000/inquiry \n' \
                      f'\t Remark: {request.data.get("remark")}\n' \
                      F'\t Your Loan Status: {request.data.get("loanstatus")} \n'\
                      F'\t Your Loan Remark: {request.data.get("loanremark")} \n'\
                      f'Sincerely,\n' \
                      f'Sukhad Loan'
            send_mail(subject, message, email_from, [user_email])
        else:
            pass
        kwargs['partial'] = True
        return self.update(request, *args, **kwargs)