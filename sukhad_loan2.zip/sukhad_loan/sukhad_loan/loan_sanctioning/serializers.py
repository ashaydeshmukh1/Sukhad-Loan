from rest_framework import serializers, fields
from application_generation.models import Application, Loan #Document, User
from disbursement.models import Installment
from django.core.mail import send_mail
import logging

logger = logging.getLogger('django')
# _______________________________ SIMPLE ___________________________________
class LoanSanctionModelSerializer(serializers.ModelSerializer):
    # id = serializers.IntegerField(read_only=True)
    # total_amount_and_processing_fees = serializers.FloatField(label='Processing Fees')
    class Meta:
        model = Loan
        fields = '__all__'
        # read_only_fields = ('loan_principal_amount', 'loan_tenure')
    def create(self, validated_data):
        logger.info('Loan status and remark updated')
        return Loan.objects.create(**validated_data)

class ApplicationModelSerializer(serializers.ModelSerializer):
    # id = serializers.IntegerField(read_only=True)
    class Meta:
        model = Application
        fields = '__all__'
    def create(self, validated_data):
        logger.info('Application status and remark updated')
        return Application.objects.create(**validated_data)

# class ActiveUserSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = User
#         fields = ('id', 'email', 'password', 'first_name', 'last_name', 'dob', 'gender', 'address', 'city', 'state', 'country', 'pin_code', 'mobile', 'photo', 'signature', 'role')
#         lookup_field = 'email'