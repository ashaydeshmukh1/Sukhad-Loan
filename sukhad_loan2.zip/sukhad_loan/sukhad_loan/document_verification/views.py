from django.shortcuts import render


from .serializers import ApplicationSerializer, DocumentSerializer, UserSerializer
from application_generation.models import Application, Document, User
from rest_framework import viewsets
from rest_framework.response import Response
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework.permissions import IsAuthenticated


class VerificationViewSet(viewsets.ModelViewSet):
    '''
    def list(self, request):
        queryset = Application.objects.all()
        serializer = ApplicationSerializer(queryset, many=True)
        return Response(serializer.data)

    def retrieve(self, request, pk):
        queryobject = Application.objects.get(pk=pk)
        serializer = ApplicationSerializer(queryobject)
        return Response(data=serializer.data)

    def partial_update(self, request, pk):
        queryobject = Application.objects.get(pk=pk)
        serializer = ApplicationSerializer(data=request.data, instance=queryobject)
        if serializer.is_valid():
            serializer.save()
            return Response(data=serializer.data)
    '''

    queryset = Application.objects.all()
    serializer_class = ApplicationSerializer
    http_method_names = ['get', 'patch']
    #queryset = Application.objects.all()
    #for i in queryset:
        #print(type(i.user))


class DocVerificationViewSet(viewsets.ModelViewSet):
    
    queryset = Document.objects.all()
    serializer_class = DocumentSerializer
    http_method_names = ['get', 'patch']
    
   
class UserVerificationViewSet(viewsets.ModelViewSet):
    
    queryset = User.objects.all()
    serializer_class = UserSerializer
    http_method_names = ['get', 'patch']
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def list(self, request):
        users = User.objects.all()
        user_list = []
        for user in users:
            if len(user.Applications.all()) != 0:
                #print(user.Applications.all())
                '''
                for app in user.Applications.all():
                    #print(app.status)
                    #print(app.Documents.status)
                    
                    if app.status == 'generated' or app.Documents.status == 'pending':
                '''
                user_list.append(user)
        serializer = UserSerializer(user_list, many=True)
        return Response(data=serializer.data)


