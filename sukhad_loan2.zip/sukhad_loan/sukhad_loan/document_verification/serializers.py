from application_generation.models import Application, Document, User
from rest_framework import serializers
import logging
from django.core.mail import send_mail
from django.conf import settings

logger = logging.getLogger('django')

#logger = logging.getLogger(__name__)

#class UserSerializer(serializers.ModelSerializer):

    #Applications = ApplicationSerializer(many=True)
    #class Meta:
        #model = User
        #fields = ('first_name', 'last_name', 'dob', 'Applications')




class DocumentSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField()
    class Meta:
        model = Document
        fields = '__all__'

        read_only_fields = ('application', 'aadhaar_card', 'pan_card', 'business_address_proof_or_copy_of_rent_agreement',
        'electric_bill', 'msme_certificate', 'gst_certificate', 'udyog_aadhaar_registration', 'business_license',
        'business_plan_or_proposal', 'three_year_itr_with_balance_sheet', 'collateral_document', 'stamp_duty',
        'response_timestamp')


class ApplicationSerializer(serializers.ModelSerializer):

    Documents = DocumentSerializer()
    id = serializers.IntegerField()
    class Meta:
        model = Application
        fields = '__all__'
        # extra_kwargs = {'user_first_name': {'label': 'First_Name'}}

        read_only_fields = ('user','aadhaar_no', 'pan_no', 'type_of_employment', 'business_title',
                            'business_type', 'business_address', 'gst_registration_no', 'business_license_no',
                            'expected_average_annual_turnover', 'years_in_current_business', 'collateral',
                            'application_timestamp')

        # extra_kwargs = {'user__first_name': {'label': 'First Name'}}


class UserSerializer(serializers.ModelSerializer):

    Applications = ApplicationSerializer(many=True)  #Nested Application model with User Mode
    id = serializers.IntegerField()
    class Meta:
        model = User
        fields = ('id','first_name', 'last_name', 'dob', 'email', 'mobile','dob','gender','address','photo', 'Applications')
        read_only_fields = ('photo',)


    def update(self, instance , validated_data):

        applications = validated_data.pop('Applications')
        #print(applications)
        #documents = applications.pop('Documents')
        for app in applications:
            app_id = app.get('id', None)
            document = app.get('Documents', None)

            #print(app_id)
            if app_id:
                app_user = Application.objects.get(id=app_id, user=instance)
                app_user.status = app.get('status', app_user.status)
                app_user.remark = app.get('remark', app_user.remark)
                app_user.save()
                logger.info('Application status and remark updated')
                doc_id = document.get('id', None)

                if doc_id:
                    doc_app = Document.objects.get(id=doc_id)
                    doc_app.status = document.get('status', doc_app.status)
                    doc_app.remark = document.get('remark', doc_app.remark)
                    doc_app.save()
                    logger.info('Document status and remark updated')

                    if app_user.status == 'rejected' or doc_app.status == 'rejected':
                        user_email = validated_data.get('email', None)
                        user_name = validated_data.get('first_name', None)
                        email_from = settings.EMAIL_HOST_USER
                        subject = f'Rejection of Request of Loan'
                        message = f'Dear {user_name}.\n' \
                                  f'\tAfter reviewing your loan application,\n ' \
                                  f'\tWe regret to inform you that your request for the loan has been rejected\n' \
                                  f'\tFor more details please contact our loan representative\n' \
                                  f'Sincerely,\n' \
                                  f'Operation Head Department'

                        send_mail(subject, message, email_from, [user_email])

                else:
                    logger.error('Cannot Update document status and remark')
            else:
                logger.error('Cannot Update application status and remark')
        return instance
    logger.info('User Data Outgoing')
