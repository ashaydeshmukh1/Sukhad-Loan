from django.apps import AppConfig


class DocumentVerificationConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'document_verification'
