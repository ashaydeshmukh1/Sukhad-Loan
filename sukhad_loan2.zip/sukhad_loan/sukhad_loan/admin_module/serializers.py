
from rest_framework import serializers,status
from application_generation.models import CustomUserManager
from application_generation.models import Inquiry
from rest_framework.response import Response


# from django.contrib.auth.models import User
from django.contrib.auth import get_user_model


User = get_user_model()
class UserModelSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = '__all__'

    def create(self, validated_data):
        return User.objects.create_user(**validated_data)

    def update(self, instance, validated_data):
        return super().update(instance, validated_data)
    
    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        self.perform_destroy(instance)
        return Response(status=status.HTTP_204_NO_CONTENT)

    


class InquirySerializer(serializers.ModelSerializer):
    class Meta:
        model= Inquiry
        fields= '__all__'

    def create(self, validated_data):
        return Inquiry.objects.create(**validated_data)
   

    def update(self, instance, validated_data):
        return super().update(instance, validated_data)

    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        self.perform_destroy(instance)
        return Response(status=status.HTTP_204_NO_CONTENT)


class ActiveUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ('id', 'email', 'password', 'first_name', 'last_name', 'dob', 'gender', 'address', 'city', 'state', 'country', 'pin_code', 'mobile', 'photo', 'signature', 'role')
        lookup_field = 'email'

