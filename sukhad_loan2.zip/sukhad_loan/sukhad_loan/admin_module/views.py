from django.shortcuts import render
from .serializers import UserModelSerializer,InquirySerializer,ActiveUserSerializer

from django.contrib.auth import get_user_model
from rest_framework.viewsets import ModelViewSet
from application_generation.models import Inquiry

from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework.permissions import BasePermission, IsAuthenticated



User = get_user_model()

class AppGen(ModelViewSet):
    queryset= User.objects.all()
    serializer_class= UserModelSerializer


class AppGenInquiry(ModelViewSet):
    queryset = Inquiry.objects.all()
    serializer_class = InquirySerializer



# class PostOnly(BasePermission):
#     def has_permission(self, request, view):
#         return bool(
#             request.method == 'POST' or
#             request.user and
#             request.user.is_authenticated
#         )

class AdminActiveUserModelViewSet(ModelViewSet):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]
    queryset = User.objects.all()
    serializer_class = ActiveUserSerializer
    lookup_field = 'email'
    lookup_value_regex = "[^/]+"