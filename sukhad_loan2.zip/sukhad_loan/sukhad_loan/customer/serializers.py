from django.contrib.auth.hashers import make_password
from django.contrib.auth.models import User
from rest_framework import serializers
from application_generation.models import *
from disbursement.models import *
from django.contrib.auth import get_user_model

User = get_user_model()


##################################          Loan--Disbursements, Installments         #########################################


class DisbursementModelSerializer(serializers.ModelSerializer):
    class Meta:
        model = Disbursement
        # fields = "__all__"
        fields = ('id', 'loan', 'insurance_doc', 'payment_mode', 'net_disbursed_amount',
                  'disbursed_to_account_no', 'receipt_doc', 'status', 'response_timestamp')

    def create(self, validated_data):
        return Disbursement.objects.create(**validated_data)


class InstallmentModelSerializer(serializers.ModelSerializer):
    class Meta:
        model = Installment
        fields = ('id', 'loan', 'remaining_amount', 'installment_no', 'monthly_installment_amount',
                  'installment_expected_date', 'installment_paid_date', 'penalty_amount', 'status')

    def create(self, validated_data):
        return Installment.objects.create(**validated_data)


class LoanModelSerializer(serializers.ModelSerializer):
    Disbursements = DisbursementModelSerializer(read_only=True)
    Installments = InstallmentModelSerializer(read_only=True, many=True)

    class Meta:
        model = Loan
        fields = ('id',  'application', 'loan_principal_amount', 'loan_tenure', 'interest_rate', 'total_amount_and_processing_fees',
                  'installment', 'maturity_date', 'sanction_letter', 'status', 'response_timestamp', 'remark', 'Installments', 'Disbursements')

    def create(self, validated_data):
        return Loan.objects.create(**validated_data)

#####################                 Application-  Loans,Guarantor,Documents,Vendors              ###########################


class GuarantorModelSerializer(serializers.ModelSerializer):
    class Meta:
        model = Guarantor
        fields = ('id', 'application', 'relation_with_customer', 'name', 'dob', 'gender', 'email', 'address', 'city', 'state', 'country',
                  'pin_code', 'mobile', 'photo', 'profession', 'income_certificate', 'bank_name', 'current_account_no', 'passbook_copy', 'ifsc_code', )

    def create(self, validated_data):
        return Guarantor.objects.create(**validated_data)


class DocumentModelSerializer(serializers.ModelSerializer):
    class Meta:
        model = Document
        fields = ('id',  'application', 'aadhaar_card', 'pan_card', 'business_address_proof_or_copy_of_rent_agreement', 'electric_bill', 'msme_certificate', 'gst_certificate',
                  'udyog_aadhaar_registration', 'business_license', 'business_plan_or_proposal', 'three_year_itr_with_balance_sheet', 'collateral_document', 'stamp_duty', 'status', 'response_timestamp', 'remark')

    def create(self, validated_data):
        return Document.objects.create(**validated_data)


class VendorModelSerializer(serializers.ModelSerializer):
    class Meta:
        model = Vendor
        fields = ('id', 'application', 'name', 'vendor_type', 'email', 'address', 'city', 'state', 'country',
                  'pin_code', 'mobile', 'bank_name', 'passbook_copy', 'current_account_no', 'ifsc_code')

    def create(self, validated_data):
        return Vendor.objects.create(**validated_data)


class ApplicationModelSerializer(serializers.ModelSerializer):
    Loans = LoanModelSerializer(read_only=True)
    Guarantors = GuarantorModelSerializer(read_only=True)
    Documents = DocumentModelSerializer(read_only=True)
    Vendors = VendorModelSerializer(read_only=True, many=True)

    class Meta:
        model = Application
        fields = ('id', 'user', 'aadhaar_no', 'pan_no', 'type_of_employment', 'business_title', 'business_type', 'business_address', 'gst_registration_no',
                  'business_license_no', 'expected_average_annual_turnover', 'years_in_current_business', 'collateral', 'status', 'application_timestamp', 'remark',  'Loans', 'Guarantors', 'Documents', 'Vendors')

    def create(self, validated_data):
        return Application.objects.create(**validated_data)


#########################       UserDetails-- Banks, Familys, Applications, Defaulters    ##################################

class BankModelSerializer(serializers.ModelSerializer):
    class Meta:
        model = Bank
        fields = ('id', 'user', 'bank_name', 'current_account_no',
                  'ifsc_code', 'passbook_copy')

    def create(self, validated_data):
        return Bank.objects.create(**validated_data)


class DefaulterModelSerializer(serializers.ModelSerializer):
    class Meta:
        model = Defaulter
        fields = ('id', 'user', 'default_amount',
                  'pending_since_date')

    def create(self, validated_data):
        return Defaulter.objects.create(**validated_data)


class FamilyModelSerializer(serializers.ModelSerializer):
    class Meta:
        model = Family
        fields = ('id', 'user', 'father_name', 'father_profession', 'mother_name', 'mother_profession',
                  'marital_status', 'spouse_name', 'spouse_profession', 'mobile', 'address')

    def create(self, validated_data):
        return Family.objects.create(**validated_data)


class UserDetailsModelSerializer(serializers.ModelSerializer):
    Banks = BankModelSerializer(read_only=True,)
    Familys = FamilyModelSerializer(read_only=True,)
    Defaulters = DefaulterModelSerializer(read_only=True)
    Applications = ApplicationModelSerializer(read_only=True, many=True)

    class Meta:
        model = User
        fields = ('id', 'email', 'password', 'first_name', 'last_name', 'dob', 'gender', 'address',
                  'city', 'state', 'country', 'pin_code', 'mobile', 'photo', 'signature', 'role', 'Banks', 'Familys', 'Applications', 'Defaulters')
        lookup_field = 'id'

    def create(self, validated_data):
        return User.objects.create_user(**validated_data)


class ActiveUserSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True)

    class Meta:
        model = User
        fields = ('id', 'email', 'password', 'first_name', 'last_name', 'dob', 'gender', 'address',
                  'city', 'state', 'country', 'pin_code', 'mobile', 'photo', 'signature', 'role')
        lookup_field = 'id'


class SignUpSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True)

    class Meta:
        model = User
        fields = ('password', 'email', 'first_name', 'last_name', 'mobile')

    def create(self, validated_data):
        return User.objects.create_user(**validated_data)


'''
class UserModelSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = User
        fields = ('id', 'email', 'password', 'first_name', 'last_name', 'dob', 'gender', 'address',
                  'city', 'state', 'country', 'pin_code', 'mobile', 'photo', 'signature', 'role')
        lookup_field = 'email'

    def create(self, validated_data):
        return User.objects.create_user(**validated_data)

    def validate_password(self, value: str) -> str:
        """
        Hash value passed by user.

        :param value: password of a user
        :return: a hashed version of the password
        """
        return make_password(value)
'''
