from django.contrib.auth import get_user_model
from application_generation.models import *
from disbursement import *
from .serializers import *
from rest_framework import views, viewsets, status, response

from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework.permissions import IsAuthenticated, BasePermission

User = get_user_model()


class PostOnly(BasePermission):
    def has_permission(self, request, view):
        return bool(
            request.method == 'POST' or
            request.user and
            request.user.is_authenticated
        )


class UserDetailsModelViewSet(viewsets.ModelViewSet):
    queryset = User.objects.all()
    serializer_class = UserDetailsModelSerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]


class SignUpAPIView(views.APIView):
    def post(self, request):
        serializer = SignUpSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return response.Response(data=serializer.data, status=status.HTTP_201_CREATED)
        return response.Response(data=serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class CustomerActiveUserModelViewSet(viewsets.ModelViewSet):
    queryset = User.objects.all()
    serializer_class = ActiveUserSerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [PostOnly]
    lookup_field = 'email'
    lookup_value_regex = "[^/]+"  # default is "[^/.]+"


class CustomerApplicationModelViewSet(viewsets.ModelViewSet):
    queryset = Application.objects.all()
    serializer_class = ApplicationModelSerializer