from django.contrib import admin

# Register your models here.
from application_generation.models import *
from disbursement.models import *

##################################          Inquiry             ###############################################################


@admin.register(Inquiry)
class InquiryAdmin(admin.ModelAdmin):
    list_display = [field.name for field in Inquiry._meta.get_fields()]


########################################        User            #############################################################
@admin.register(User)
class UserAdmin(admin.ModelAdmin):
    list_display = ('id', 'first_name', 'last_name', 'dob', 'gender', 'email', 'address', 'city', 'state', 'country',
                    'pin_code', 'mobile', 'photo', 'signature', 'role', 'is_staff', 'is_active', 'is_superuser', )


####################################   User--Banks, Familys, Applications, Defaulters        #################################


@admin.register(Bank)
class BankAdmin(admin.ModelAdmin):
    list_display = ('id', 'user', 'bank_name',
                    'current_account_no', 'ifsc_code', )


@admin.register(Family)
class FamilyAdmin(admin.ModelAdmin):
    list_display = ('id', 'user', 'father_name', 'father_profession', 'mother_name', 'mother_profession',
                    'marital_status', 'spouse_name', 'spouse_profession', 'mobile', 'address',)


@admin.register(Defaulter)
class DefaulterAdmin(admin.ModelAdmin):
    list_display = ('id', 'user', 'default_amount',
                    'pending_since_date', )


@admin.register(Application)
class ApplicationAdmin(admin.ModelAdmin):
    list_display = ('id', 'user', 'aadhaar_no', 'pan_no', 'type_of_employment', 'business_title', 'business_type', 'business_address', 'gst_registration_no',
                    'business_license_no', 'expected_average_annual_turnover', 'years_in_current_business', 'collateral', 'status', 'application_timestamp', 'remark')


#########################      Application-- Loans, Documents, Guarantors, Vendors      #################################


@admin.register(Loan)
class LoanAdmin(admin.ModelAdmin):
    list_display = ('id', 'application', 'loan_principal_amount', 'loan_tenure', 'interest_rate', 'total_amount_and_processing_fees',
                    'installment', 'maturity_date', 'sanction_letter', 'status', 'response_timestamp', 'remark', )


@admin.register(Document)
class DocumentAdmin(admin.ModelAdmin):
    list_display = ('id', 'application', 'aadhaar_card', 'pan_card', 'business_address_proof_or_copy_of_rent_agreement', 'electric_bill', 'msme_certificate', 'gst_certificate', 'udyog_aadhaar_registration',
                    'business_license', 'business_plan_or_proposal', 'three_year_itr_with_balance_sheet', 'collateral_document', 'stamp_duty', 'status', 'response_timestamp', 'remark',)


@admin.register(Guarantor)
class GuarantorAdmin(admin.ModelAdmin):
    list_display = ('id', 'application', 'relation_with_customer', 'name', 'dob', 'gender', 'email', 'address', 'city', 'state', 'country', 'pin_code',
                    'mobile', 'photo', 'profession', 'income_certificate', 'bank_name', 'current_account_no', 'passbook_copy', 'ifsc_code', )


@admin.register(Vendor)
class VendorAdmin(admin.ModelAdmin):
    list_display = ('id', 'application', 'name', 'vendor_type', 'email', 'address', 'city', 'state', 'country',
                    'pin_code', 'mobile', 'bank_name', 'passbook_copy', 'current_account_no', 'ifsc_code',)


#######################################         Loan- Installment , Disbursement        ######################################


@admin.register(Installment)
class InstallmentAdmin(admin.ModelAdmin):
    list_display = ('id', 'loan', 'remaining_amount', 'installment_no', 'monthly_installment_amount',
                    'installment_expected_date', 'installment_paid_date', 'penalty_amount', 'status', )


@admin.register(Disbursement)
class DisbursementAdmin(admin.ModelAdmin):
    list_display = ('id', 'loan', 'insurance_doc', 'payment_mode', 'net_disbursed_amount',
                    'disbursed_to_account_no', 'receipt_doc', 'status', 'response_timestamp', )
