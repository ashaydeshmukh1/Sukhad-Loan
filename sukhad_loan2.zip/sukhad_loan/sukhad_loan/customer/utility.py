GENDER_CHOICES = (
    ('', ''),
    ('male', 'male'),
    ('female', 'female'),
    ('transgender', 'transgender')
)

MARITAL_STATUS = (
    ('', ''),
    ('married', 'married'),
    ('unmarried', 'unmarried')
)

DOCUMENT_STATUS_CHOICE = (
    ('', ''),
    ('pending', 'pending'),
    ('done', 'done'),
    ('rejected', 'rejected'),
)

LOAN_STATUS_CHOICE = (
    ('', ''),
    ('pending', 'pending'),
    ('done', 'done'),
    ('rejected', 'rejected'),
)

EMPLOYMENT_CHOICE = (
    ('', ''),
    ('self_employed', 'self_employed'),
    ('salaried', 'salaried'),
)

BUSINESS_TYPE = (
    ('', ''),
    ('manufacturing', 'manufacturing'),
    ('service', 'service'),
    ('trading', 'trading'),
)

APPLICATION_STATUS = (
    ('', ''),
    ('generated', 'generated'),
    ('document_verified', 'document_verified'),
    ('sanctioned', 'sanctioned'),
    ('disbursed', 'disbursed'),
    ('rejected', 'rejected')
)


INSTALLMENT_CHOICES = (
    ('', ''),
    ('ok', 'ok'),
    ('pending', 'pending'),
    ('late', 'late')
)

PAYMENT_CHOICES = (
    ('', ''),
    ('neft', 'neft'),
    ('rtgs', 'rtgs'),
    ('imps', 'imps'),
)

DISBURSEMENT_CHOICES = (
    ('', ''),
    ('pending', 'pending'),
    ('disbursed', 'disbursed'),
)


ROLE_CHOICES = (
    ('customer', 'customer'),
    ('loan_representative', 'loan_representative'),
    ('operational_head', 'operational_head'),
    ('loan_sanctioning_officer', 'loan_sanctioning_officer'),
    ('account_head', 'account_head'),
    ('admin', 'admin'),
)

INQUIRY_STATUS = (
    ('', ''),
    ('pending', 'pending'),
    ('done', 'done'),
    ('rejected', 'rejected'),
)
